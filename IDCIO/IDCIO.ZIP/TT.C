main()
{
  static char *weekdays[] = {"S\24n", "M\06n", "Tis", "Ons", "Tor", "Fre", 
                            "L\24r" };

}
