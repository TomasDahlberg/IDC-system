#include <stdio.h>

int main()
{
  double qw;
  
  qw = 1e-100;
  while (1)
  {
    printf("%f\n", qw);
  }
}
